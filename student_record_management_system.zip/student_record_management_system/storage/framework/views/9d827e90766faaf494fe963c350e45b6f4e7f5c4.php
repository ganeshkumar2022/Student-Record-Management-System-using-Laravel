<?php $__env->startSection('title','Admin Panel | Student Record Management System'); ?>
<?php $__env->startSection('content'); ?>
<style>
    .myulasdd li a
    {
        padding:13px;
        font-size:18px;
    }
</style>
<body>
    <div class="bg-light text-dark p-3"><h5 class="fw-normal">Student Record Management System</h5></div>
    <div style="width:100%;">
        <?php echo $__env->make('admin.aheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div style="width:80%;float:left;">
            <div class="container-fluid">
            <h4 class="pt-4 pb-3">WELCOME ADMIN</h4>
            <div class="card">
                <div class="card-header">Edit Subject</div>
                <div class="card-body">
                   <form method="post" autocomplete="off" action="<?php echo e(route('update_subject',$data->subject_id)); ?>">
                    <?php echo method_field('PUT'); ?>
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-md-3">
                          <label>Course short name :</label>
                        </div>
                        <div class="col-md-6">
                          <select class="form-select" name="course_id">
                            <option value="">Choose Course</option>
                            <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($course->id); ?>" <?php echo e($data->course_id==$course->id ? "selected" : ""); ?> ><?php echo e($course->course_name."(".$course->full_name.")"); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                          <span class="text-danger"><?php echo e($errors->first('course_id')); ?></span>
                        </div>
                      </div>
                      <div class="row mt-3">
                        <div class="col-md-3">
                          <label>Subject 1 :</label>
                        </div>
                        <div class="col-md-6">
                          <input type="text" class="form-control" placeholder="Enter Subject 1" value="<?php echo e($data->subject1); ?>" name="subject1">
                          <span class="text-danger"><?php echo e($errors->first('subject1')); ?></span>
                        </div>
                      </div>
                      <div class="row mt-3">
                        <div class="col-md-3">
                          <label>Subject 2 :</label>
                        </div>
                        <div class="col-md-6">
                          <input type="text" class="form-control" placeholder="Enter Subject 2" value="<?php echo e($data->subject2); ?>" name="subject2">
                          <span class="text-danger"><?php echo e($errors->first('subject2')); ?></span>
                        </div>
                      </div>
                      <div class="row mt-3">
                        <div class="col-md-3">
                          <label>Subject 3 :</label>
                        </div>
                        <div class="col-md-6">
                          <input type="text" class="form-control" placeholder="Enter Subject 3" value="<?php echo e($data->subject3); ?>" name="subject3">
                          <span class="text-danger"><?php echo e($errors->first('subject3')); ?></span>
                        </div>
                      </div>
                      <div class="row mt-3">
                        <div class="col-md-3">
                          <label>Subject 4 :</label>
                        </div>
                        <div class="col-md-6">
                          <input type="text" class="form-control" placeholder="Enter Subject 4" value="<?php echo e($data->subject4); ?>" name="subject4">
                          <span class="text-danger"><?php echo e($errors->first('subject4')); ?></span>
                        </div>
                      </div>
                      <div class="mt-3">
                        <input type="submit" name="create" value="Update Subject" class="btn btn-primary">
                      </div>
                   </form>
                </div>
            </div>
        </div>
        </div>
    </div>
    <?php if(session('message')): ?>
      <script>
        alert("<?php echo e(session('message')); ?>");
      </script>
    <?php endif; ?>
</body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('../layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\practice\student_record_management_system\resources\views/admin/edit_subject.blade.php ENDPATH**/ ?>