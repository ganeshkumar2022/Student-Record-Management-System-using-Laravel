<?php $__env->startSection('title','Admin Panel | Student Record Management System'); ?>
<?php $__env->startSection('content'); ?>
<style>
    .myulasdd li a
    {
        padding:13px;
        font-size:18px;
    }
</style>
<body>
    <div class="bg-light text-dark p-3"><h5 class="fw-normal">Student Record Management System</h5></div>
    <div style="width:100%;">
        <?php echo $__env->make('admin.aheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div style="width:80%;float:left;">
            <div class="container-fluid">
            <h4 class="pt-4 pb-3">WELCOME ADMIN</h4>
            <div class="card">
                <div class="card-header">Dashboard</div>
                <div class="card-body">
                    <div class="row">







                            <!-- one card start-->
                        <div class="col-md-4 mt-4">
                            <div class="card">
                                <div class="card-body" style="background-color:rgb(137, 139, 0);color:white;">
                                    <div class="clearfix">
                                    <div class="float-start">
                                        <i class="fa-solid fa-file" style="font-size:80px;"></i>
                                    </div>
                                    <div class="float-end">
                                        <h2 class="text-end"><?php echo e($courses); ?></h2>
                                        <p>Courses</p>
                                    </div>
                                    </div>
                                </div>
                                <div class="card-footer">
                                    <div class="clearfix" style="color:rgb(137, 139, 0);">
                                        <div class="float-start"><a href="<?php echo e(route('view_course')); ?>" class="text-reset text-decoration-none">View Courses</a></div>
                                        <div class="float-end"><i class="fa-solid fa-circle-chevron-right"></i></div>
                                    </div>
                                </div>
                            </div>
                            </div>
                            <!-- one card end-->

                            <!-- one card start-->
                            <div class="col-md-4 mt-4">
                            <div class="card">
                                <div class="card-body" style="background-color:rgb(192, 17, 154);color:white;">
                                    <div class="clearfix">
                                    <div class="float-start">
                                        <i class="fa-solid fa-file" style="font-size:80px;"></i>
                                    </div>
                                    <div class="float-end">
                                        <h2 class="text-end"><?php echo e($subjects); ?></h2>
                                        <p>Subjects</p>
                                    </div>
                                    </div>
                                </div>
                                <div class="card-footer">
                                    <div class="clearfix" style="color:rgb(192, 17, 154);">
                                        <div class="float-start"><a href="<?php echo e(route('view_subjects')); ?>" class="text-reset text-decoration-none">View Subjects</a></div>
                                        <div class="float-end"><i class="fa-solid fa-circle-chevron-right"></i></div>
                                    </div>
                                </div>
                            </div>
                            </div>
                            <!-- one card end-->

                            <!-- one card start-->
                            <div class="col-md-4 mt-4">
                            <div class="card">
                                <div class="card-body" style="background-color:rgb(226, 175, 66);color:white;">
                                    <div class="clearfix">
                                    <div class="float-start">
                                        <i class="fa-solid fa-file" style="font-size:80px;"></i>
                                    </div>
                                    <div class="float-end">
                                        <h2 class="text-end"><?php echo e($students); ?></h2>
                                        <p>Students</p>
                                    </div>
                                    </div>
                                </div>
                                <div class="card-footer">
                                    <div class="clearfix" style="color:rgb(226, 175, 66);">
                                        <div class="float-start"><a href="<?php echo e(route('view_students')); ?>" class="text-reset text-decoration-none">View Students</a></div>
                                        <div class="float-end"><i class="fa-solid fa-circle-chevron-right"></i></div>
                                    </div>
                                </div>
                            </div>
                            </div>
                            <!-- one card end-->

                    </div>
                </div>
            </div>
        </div>
        </div>
    </div>
</body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('../layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\practice\student_record_management_system\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>