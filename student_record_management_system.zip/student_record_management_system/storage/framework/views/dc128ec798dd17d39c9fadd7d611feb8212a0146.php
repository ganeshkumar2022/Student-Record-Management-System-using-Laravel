<?php $__env->startSection('title','Student Record Management System'); ?>
<?php $__env->startSection('content'); ?>
<style>
    body
    {
        background-image:url('<?php echo e(asset('images/bg.jpg')); ?>');
        background-repeat:no-repeat;
        background-size:100% 100%;
        height:100vh;
    }
</style>
<body>
    <div class="container">
        <h3 class="p-4 "><center>Student Record Management System</center></h3>
        <div class="row">
            <div class="col-md-6 offset-3">
                <div class="card">
                    <div class="card-header bg-info text-white"><h4>Sign in</h4></div>
                    <div class="card-body" style="border:3px solid #0dcaf0;">
                            <form action="<?php echo e(route('admin.login')); ?>" method="post" autocomplete="off">
                            <?php echo csrf_field(); ?>
                            <div class="mb-3 mt-3">
                              <label for="login_id" class="form-label">Login Id:</label>
                              <input type="text" class="form-control" id="login_id" value="<?php echo e(old('login_id')); ?>" placeholder="Enter Login Id" name="login_id">
                              <span class="text-danger"><?php echo e($errors->first('login_id')); ?></span>
                            </div>
                            <div class="mb-3">
                              <label for="password" class="form-label">Password:</label>
                              <input type="password" class="form-control" id="password" value="<?php echo e(old('password')); ?>" placeholder="Enter password" name="password">
                              <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
                            </div>
                            <button type="submit" class="btn btn-primary">Login</button>
                          </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php if(session('error')): ?>
<script>
    alert("<?php echo e(session('error')); ?>");
</script>
<?php endif; ?>
</body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\practice\student_record_management_system\resources\views/home.blade.php ENDPATH**/ ?>