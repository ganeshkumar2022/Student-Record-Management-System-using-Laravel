<?php $__env->startSection('title','Admin Panel | Student Record Management System'); ?>
<?php $__env->startSection('content'); ?>
<style>
    .myulasdd li a
    {
        padding:13px;
        font-size:18px;
    }
</style>
<body>
    <div class="bg-light text-dark p-3"><h5 class="fw-normal">Student Record Management System</h5></div>
    <div style="width:100%;">
        <?php echo $__env->make('admin.aheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div style="width:80%;float:left;">
            <div class="container-fluid">
            <h4 class="pt-4 pb-3">WELCOME ADMIN</h4>
            <div class="card">
                <div class="card-header">View Session</div>
                <div class="card-body">
                   <form method="post" autocomplete="off" action="<?php echo e(route('update_session',$data->id)); ?>">
                    <?php echo method_field('PUT'); ?>
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-md-3">
                          <label>Session</label>
                        </div>
                        <div class="col-md-6">
                          <p>Current Session : <?php echo e($data->mysession_name); ?></p>
                          <input type="radio" name="my_session" value="2016-2017"> 2016-2017<br>
                          <input type="radio" name="my_session" value="2017-2018"> 2017-2018<br>
                          <input type="radio" name="my_session" value="2018-2019"> 2018-2019<br>
                          <input type="radio" name="my_session" value="2019-2020"> 2019-2020<br>
                          <input type="radio" name="my_session" value="2020-2021"> 2020-2021<br>
                          <input type="radio" name="my_session" value="2021-2022"> 2021-2022<br>
                          <input type="radio" name="my_session" value="2022-2023"> 2022-2023<br>
                          <input type="radio" name="my_session" value="2023-2024"> 2023-2024<br>
                          <input type="radio" name="my_session" value="2024-2025"> 2024-2025<br>
                          <input type="radio" name="my_session" value="2025-2026"> 2025-2026<br>
                          <span class="text-danger"><?php echo e($errors->first('my_session')); ?></span>
                        </div>
                      </div>

                      <div class="mt-3">
                        <input type="submit" name="create" value="Update Session" class="btn btn-primary">
                      </div>
                   </form>
                </div>
            </div>
        </div>
        </div>
    </div>
    <?php if(session('message')): ?>
      <script>
        alert("<?php echo e(session('message')); ?>");
      </script>
    <?php endif; ?>
</body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('../layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\practice\student_record_management_system\resources\views/admin/add_session.blade.php ENDPATH**/ ?>