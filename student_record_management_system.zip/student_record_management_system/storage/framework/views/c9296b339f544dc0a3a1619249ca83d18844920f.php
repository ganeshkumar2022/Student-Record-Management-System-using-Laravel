<?php $__env->startSection('title','Admin Panel | Student Record Management System'); ?>
<?php $__env->startSection('content'); ?>
<style>
    .myulasdd li a
    {
        padding:13px;
        font-size:18px;
    }
</style>
<body>
    <div class="bg-light text-dark p-3"><h5 class="fw-normal">Student Record Management System</h5></div>
    <div style="width:100%;">
        <?php echo $__env->make('admin.aheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div style="width:80%;float:left;">
            <div class="container-fluid">
            <h4 class="pt-4 pb-3">WELCOME ADMIN</h4>
            <div class="card">
                <div class="card-header">Change password</div>
                <div class="card-body">
                   <form method="post" autocomplete="off" action="<?php echo e(route('change_password')); ?>">
                    <?php echo method_field('PUT'); ?>
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-md-3">
                          <label>Current password :</label>
                        </div>
                        <div class="col-md-6">
                          <input type="password" class="form-control" placeholder="Enter Current password" value="<?php echo e(old('current_password')); ?>" name="current_password">
                          <span class="text-danger"><?php echo e($errors->first('current_password')); ?></span>
                        </div>
                      </div>
                      <div class="row mt-3">
                        <div class="col-md-3">
                          <label>New Password :</label>
                        </div>
                        <div class="col-md-6">
                          <input type="password" class="form-control" placeholder="Enter New Password" value="<?php echo e(old('password')); ?>" name="password">
                          <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
                        </div>
                      </div>
                      <div class="row mt-3">
                        <div class="col-md-3">
                          <label>Re type new password :</label>
                        </div>
                        <div class="col-md-6">
                          <input type="password" class="form-control"  placeholder="Enter Confirm password" value="<?php echo e(old('password_confirmation')); ?>" name="password_confirmation">
                          <span class="text-danger"><?php echo e($errors->first('password_confirmation')); ?></span>
                        </div>
                      </div>
                      <div class="mt-3">
                        <input type="submit" name="create" value="Update Password" class="btn btn-primary">
                      </div>
                   </form>
                </div>
            </div>
        </div>
        </div>
    </div>
    <?php if(session('message')): ?>
      <script>
        alert("<?php echo e(session('message')); ?>");
      </script>
    <?php endif; ?>
</body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('../layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\practice\student_record_management_system\resources\views/admin/update_password.blade.php ENDPATH**/ ?>