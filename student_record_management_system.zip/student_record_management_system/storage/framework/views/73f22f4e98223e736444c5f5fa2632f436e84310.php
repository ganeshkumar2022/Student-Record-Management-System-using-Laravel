<?php $__env->startSection('title','Admin Panel | Student Record Management System'); ?>
<?php $__env->startSection('content'); ?>
<style>
    .myulasdd li a
    {
        padding:13px;
        font-size:18px;
    }
</style>
<body>
    <div class="bg-light text-dark p-3"><h5 class="fw-normal">Student Record Management System</h5></div>
    <div style="width:100%;">
        <?php echo $__env->make('admin.aheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div style="width:80%;float:left;">
            <div class="container-fluid">
            <h4 class="pt-4 pb-3">WELCOME ADMIN</h4>
            <div class="card">
                <div class="card-header">Manage Students</div>
                <div class="card-body">
                    <table class="table table-bordered">
                        <tr class="table-primary">
                            <th>S.No</th>
                            <th>Register No</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Mobile no</th>
                            <th>Course</th>
                            <th>Subject</th>
                            <th>Action</th>
                        </tr>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($key+1); ?></td>
                            <td><?php echo e($row->student_id); ?></td>
                            <td><?php echo e($row->first_name." ".$row->middle_name." ".$row->last_name); ?></td>
                            <td><?php echo e($row->email); ?></td>
                            <td><?php echo e($row->mobile); ?></td>
                            <td><?php echo e($row->course_name); ?></td>
                            <td><?php echo e($row->subject1."+".$row->subject2."+".$row->subject3."+".$row->subject4); ?></td>
                            <td>
                                <a href="<?php echo e(route('edit_student',$row->student_id)); ?>" class="btn btn-success">Edit</a>
                                <a href="<?php echo e(route('delete_student',$row->student_id)); ?>" class="btn btn-danger">Delete</a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
        </div>
        </div>
    </div>
    <?php if(session('message')): ?>
      <script>
        alert("<?php echo e(session('message')); ?>");
      </script>
    <?php endif; ?>
</body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('../layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\practice\student_record_management_system\resources\views/admin/view_students.blade.php ENDPATH**/ ?>