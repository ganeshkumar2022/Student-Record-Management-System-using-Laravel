<?php $__env->startSection('title','Admin Panel | Student Record Management System'); ?>
<?php $__env->startSection('content'); ?>
<style>
    .myulasdd li a
    {
        padding:13px;
        font-size:18px;
    }
    ::-webkit-scrollbar {
    width: 8px;
}

</style>
<body onload="get_state(<?php echo e($student->course_id); ?>)">
    <div class="bg-light text-dark p-3"><h5 class="fw-normal">Student Record Management System</h5></div>
    <div style="width:100%;">
        <?php echo $__env->make('admin.aheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div style="width:80%;float:left;height:100vh;overflow-y:scroll;">
            <div class="container-fluid">
            <h4 class="pt-4 pb-3">WELCOME ADMIN</h4>
            <form method="post" autocomplete="off" action="<?php echo e(route('update_student',$student->student_id)); ?>">
                <?php echo method_field('PUT'); ?>
                <?php echo csrf_field(); ?>

            <div class="card">
                <div class="card-header">Edit Information</div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-3">
                          <label>Course short name :</label>
                        </div>
                        <div class="col-md-6">
                          <select class="form-select" name="course_id" onchange="get_state(this.value)">
                            <option value="">Choose Course</option>
                            <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($course->id); ?>" <?php echo e($student->course_id==$course->id ? "selected" : ""); ?> ><?php echo e($course->course_name."(".$course->full_name.")"); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                          <span class="text-danger"><?php echo e($errors->first('course_id')); ?></span>
                        </div>
                      </div>
                      <div class="row mt-3">
                        <div class="col-md-3">
                          <label>Select Subject :</label>
                        </div>
                        <div class="col-md-6">
                          <input type="text" class="form-control" id="mysubjects" readonly>
                        </div>
                      </div>
                      <div class="row mt-3">
                        <div class="col-md-3">
                          <label>Current Session :</label>
                        </div>
                        <div class="col-md-6">
                          <input type="text" class="form-control" name="current_session" readonly value="<?php echo e($student->current_session); ?>">
                        </div>
                      </div>
                      <div class="mt-3 mb-5">

                      </div>
                </div>
            </div>

            <!-- personal info start -->
            <div class="card my-3">
                <div class="card-header">Personal Informations</div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <!-- form content start -->
                            <div class="row">
                                <div class="col-md-6">
                                  <label>First Name :</label>
                                </div>
                                <div class="col-md-6">
                                    <input type="text" class="form-control" value="<?php echo e($student->first_name); ?>" name="first_name" id="first_name">
                                    <span class="text-danger"><?php echo e($errors->first('first_name')); ?></span>
                                </div>
                              </div>
                              <div class="row mt-3">
                                <div class="col-md-6">
                                  <label>Last Name :</label>
                                </div>
                                <div class="col-md-6">
                                  <input type="text" class="form-control" value="<?php echo e($student->last_name); ?>" name="last_name" id="last_name">
                                  <span class="text-danger"><?php echo e($errors->first('last_name')); ?></span>
                                </div>
                              </div>
                              <div class="row mt-3">
                                <div class="col-md-6">
                                  <label>Father Name / Guardian Name :</label>
                                </div>
                                <div class="col-md-6">
                                  <input type="text" class="form-control" name="guardian_name" value="<?php echo e($student->guardian_name); ?>">
                                  <span class="text-danger"><?php echo e($errors->first('guardian_name')); ?></span>
                                </div>
                              </div>
                              <div class="row mt-3">
                                <div class="col-md-6">
                                  <label>Family Income :</label>
                                </div>
                                <div class="col-md-6">
                                  <input type="text" class="form-control" name="family_income" value="<?php echo e($student->family_income); ?>">
                                  <span class="text-danger"><?php echo e($errors->first('family_income')); ?></span>
                                </div>
                              </div>
                              <div class="row mt-3">
                                <div class="col-md-6">
                                  <label>Physically Challenged :</label>
                                </div>
                                <div class="col-md-6">
                                    <select class="form-select mb-4" name="physically_challenged">
                                        <option value="">Choose</option>
                                        <option value="Yes" <?php echo e($student->physically_challenged=="Yes" ? "selected" : ""); ?> >Yes</option>
                                        <option value="No" <?php echo e($student->physically_challenged=="No" ? "selected" : ""); ?> >No</option>
                                      </select>
                                  <span class="text-danger"><?php echo e($errors->first('physically_challenged')); ?></span>
                                </div>
                              </div>
                            <!-- form content end -->
                        </div>
                        <div class="col-md-6">

                            <!-- form content start -->
                            <div class="row">
                                <div class="col-md-6">
                                  <label>Middle Name :</label>
                                </div>
                                <div class="col-md-6">
                                    <input type="text" class="form-control" value="<?php echo e($student->middle_name); ?>" name="middle_name">
                                    <span class="text-danger"><?php echo e($errors->first('middle_name')); ?></span>
                                </div>
                              </div>
                              <div class="row mt-3">
                                <div class="col-md-6">
                                  <label>Gender :</label>
                                </div>
                                <div class="col-md-6">
                                  <div>
                                    <input type="radio" name="gender" value="Male" <?php echo e($student->gender=="Male" ? "checked" :""); ?>> Male
                                    &nbsp;&nbsp;&nbsp;<input type="radio" name="gender" value="Female" <?php echo e($student->gender=="Female" ? "checked" :""); ?>> Female
                                    &nbsp;&nbsp;&nbsp;<input type="radio" name="gender" value="Others" <?php echo e($student->gender=="Others" ? "checked" :""); ?>> Others
                                  </div>
                                  <span class="text-danger"><?php echo e($errors->first('gender')); ?></span>
                                </div>
                              </div>
                              <div class="row mt-3">
                                <div class="col-md-6">
                                  <label>Occupation :</label>
                                </div>
                                <div class="col-md-6">
                                  <input type="text" class="form-control" name="occupation" value="<?php echo e($student->occupation); ?>">
                                  <span class="text-danger"><?php echo e($errors->first('occupation')); ?></span>
                                </div>
                              </div>
                              <div class="row mt-3">
                                <div class="col-md-6">
                                  <label>Caste :</label>
                                </div>
                                <div class="col-md-6">
                                    <select class="form-select" name="caste">
                                        <option value="">Choose</option>
                                        <option value="BC" <?php echo e($student->caste=="BC" ? "selected" : ""); ?> >BC</option>
                                        <option value="MBC" <?php echo e($student->caste=="MBC" ? "selected" : ""); ?> >MBC</option>
                                        <option value="OBC" <?php echo e($student->caste=="OBC" ? "selected" : ""); ?> >OBC</option>
                                        <option value="SC" <?php echo e($student->caste=="SC" ? "selected" : ""); ?> >SC</option>
                                      </select>
                                  <span class="text-danger"><?php echo e($errors->first('caste')); ?></span>
                                </div>
                              </div>
                              <div class="row mt-3">
                                <div class="col-md-6">
                                  <label>Nationality :</label>
                                </div>
                                <div class="col-md-6">
                                    <input type="text" class="form-control" name="nationality" value="<?php echo e($student->nationality); ?>">
                                    <span class="text-danger"><?php echo e($errors->first('nationality')); ?></span>
                                </div>
                              </div>
                            <!-- form content end -->
                        </div>
                    </div>

                </div>
            </div>

            <!-- personal info end -->


                        <!-- contact info start -->
                        <div class="card my-3">
                            <div class="card-header">Contact Informations</div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6">
                                        <!-- form content start -->
                                        <div class="row">
                                            <div class="col-md-6">
                                              <label>Mobile number :</label>
                                            </div>
                                            <div class="col-md-6">
                                                <input type="text" class="form-control" value="<?php echo e($student->mobile); ?>" name="mobile">
                                                <span class="text-danger"><?php echo e($errors->first('mobile')); ?></span>
                                            </div>
                                          </div>
                                          <div class="row mt-3">
                                            <div class="col-md-6">
                                              <label>Country :</label>
                                            </div>
                                            <div class="col-md-6">
                                              <input type="text" class="form-control" value="<?php echo e($student->country); ?>" name="country">
                                              <span class="text-danger"><?php echo e($errors->first('country')); ?></span>
                                            </div>
                                          </div>
                                          <div class="row mt-3">
                                            <div class="col-md-6">
                                              <label>City :</label>
                                            </div>
                                            <div class="col-md-6">
                                              <input type="text" class="form-control" name="city" value="<?php echo e($student->city); ?>">
                                              <span class="text-danger"><?php echo e($errors->first('city')); ?></span>
                                            </div>
                                          </div>
                                          <div class="row mt-3">
                                            <div class="col-md-6">
                                              <label>Correspondance address :</label>
                                            </div>
                                            <div class="col-md-6">
                                              <textarea class="form-control" name="correspondance_address" rows="5"><?php echo e($student->correspondance_address); ?></textarea>
                                              <span class="text-danger"><?php echo e($errors->first('correspondance_address')); ?></span>
                                            </div>
                                          </div>

                                        <!-- form content end -->
                                    </div>
                                    <div class="col-md-6">

                                        <!-- form content start -->
                                        <div class="row">
                                            <div class="col-md-6">
                                              <label>Email Id :</label>
                                            </div>
                                            <div class="col-md-6">
                                                <input type="text" class="form-control" value="<?php echo e($student->email); ?>" name="email">
                                                <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                                            </div>
                                          </div>
                                          <div class="row mt-3">
                                            <div class="col-md-6">
                                              <label>State :</label>
                                            </div>
                                            <div class="col-md-6">
                                              <input type="text" class="form-control" value="<?php echo e($student->state); ?>" name="state">
                                              <span class="text-danger"><?php echo e($errors->first('state')); ?></span>
                                            </div>
                                          </div>
                                          <div class="row mt-3">
                                            <div class="col-md-6">
                                              <label>Permenant address :</label>
                                            </div>
                                            <div class="col-md-6">
                                              <textarea class="form-control" name="permenant_address" rows="3"><?php echo e($student->permenant_address); ?></textarea>
                                              <span class="text-danger"><?php echo e($errors->first('permenant_address')); ?></span>
                                            </div>
                                          </div>

                                        <!-- form content end -->
                                    </div>
                                </div>

                            </div>
                        </div>

                        <!-- contact info end -->


                         <!-- academic info start -->
                         <div class="card my-3">
                          <div class="card-header">Academic Informations</div>
                          <div class="card-body">
                              <div class="row">
                                <div class="col-md-12">
                                  <table class="table table-bordered">
                                    <tr>
                                      <th><center>S.No</center></th>
                                      <th><center>Board</center></th>
                                      <th><center>Roll no</center></th>
                                      <th><center>Year of passing</center></th>
                                    </tr>
                                    <tr>

                                      <td align="center">1.</td>
                                      <td align="center">
                                       10th
                                      </td>
                                      <td align="center">
                                        <input type="text" value="<?php echo e($student->tenth_rollno); ?>" name="tenth_rollno"><br>
                                              <span class="text-danger"><?php echo e($errors->first('tenth_rollno')); ?></span>
                                      </td>
                                      <td align="center">
                                        <input type="text" value="<?php echo e($student->tenth_year_of_passing); ?>" name="tenth_year_of_passing"><br>
                                              <span class="text-danger"><?php echo e($errors->first('tenth_year_of_passing')); ?></span>
                                      </td>
                                    </tr>
                                    <tr>

                                      <td align="center">2.</td>
                                      <td align="center">
                                       12th
                                      </td>
                                      <td align="center">
                                        <input type="text" value="<?php echo e($student->twelth_rollno); ?>" name="twelth_rollno"><br>
                                              <span class="text-danger"><?php echo e($errors->first('twelth_rollno')); ?></span>
                                      </td>
                                      <td align="center">
                                        <input type="text" value="<?php echo e($student->twelth_year_of_passing); ?>" name="twelth_year_of_passing"><br>
                                              <span class="text-danger"><?php echo e($errors->first('twelth_year_of_passing')); ?></span>
                                      </td>
                                    </tr>
                                  </table>

                                  <center>
                                  <input type="submit" name="register" value="Update" class="btn btn-primary">
                                </center>
                                </div>
                              </div>

                          </div>
                      </div>

                      <!-- academic info end -->






        </form>
        </div>
        </div>
        <script>
            function get_state(a)
            {
                var xhttp=new XMLHttpRequest();
                xhttp.onload=function(){
                    var mysub=document.getElementById("mysubjects");
                    mysub.value=this.responseText;
                }
                xhttp.open("GET","/get_state/"+a,true);
                xhttp.send();
            }
        </script>
    </div>
    <?php if(session('message')): ?>
      <script>
        alert("<?php echo e(session('message')); ?>");
      </script>
    <?php endif; ?>
</body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('../layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\practice\student_record_management_system\resources\views/admin/edit_student.blade.php ENDPATH**/ ?>