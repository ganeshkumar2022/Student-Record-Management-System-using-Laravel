<?php

use App\Http\Controllers\AdminController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get("/",[AdminController::class,"index"])->name('home');
Route::post("/adminlogin",[AdminController::class,"admin_login"])->name('admin.login');
Route::get("/admin_dashboard",[AdminController::class,"admin_dashboard"])->name('admin.dashboard');
Route::get("/admin_logout",[AdminController::class,"admin_logout"]);
Route::get("/add_courses",[AdminController::class,"add_courses"])->name('add_course');
Route::post("/create_course",[AdminController::class,"create_course"])->name('create_course');
Route::get("/view_course",[AdminController::class,"view_course"])->name('view_course');
Route::get("/delete_course/{id}",[AdminController::class,"delete_course"])->name('delete_course');
Route::get("/edit_course/{id}",[AdminController::class,"edit_course"])->name('edit_course');
Route::put("/update_course/{id}",[AdminController::class,"update_course"])->name('update_course');
Route::get("/add_subject",[AdminController::class,"add_subjects"])->name('add_subject');
Route::post("/create_subject",[AdminController::class,"create_subject"])->name('create_subject');
Route::get("/view_subject",[AdminController::class,"view_subjects"])->name('view_subjects');
Route::get("/delete_subject/{id}",[AdminController::class,"delete_subject"])->name('delete_subject');
Route::get("/edit_subject/{id}",[AdminController::class,"edit_subject"])->name('edit_subject');
Route::put("/update_subject/{id}",[AdminController::class,"update_subject"])->name('update_subject');
Route::get("/register",[AdminController::class,"register"])->name('register');
Route::get("/get_state/{id}",[AdminController::class,"get_state"]);
Route::post("/register_student",[AdminController::class,"register_student"])->name('register_student');
Route::get("/view_students",[AdminController::class,"view_students"])->name('view_students');
Route::get("/delete_student/{id}",[AdminController::class,"delete_student"])->name('delete_student');
Route::get("/edit_student/{id}",[AdminController::class,"edit_student"])->name('edit_student');
Route::get("/update_password",[AdminController::class,"update_password"])->name('update_password');
Route::put("/update_student/{id}",[AdminController::class,"update_student"])->name('update_student');
Route::get("/add_session",[AdminController::class,"add_session"])->name('add_session');
Route::put("/update_session/{id}",[AdminController::class,"update_session"])->name('update_session');
Route::put("/change_password",[AdminController::class,"change_password"])->name('change_password');
