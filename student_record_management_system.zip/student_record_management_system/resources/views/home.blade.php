@extends('layouts.master')
@section('title','Student Record Management System')
@section('content')
<style>
    body
    {
        background-image:url('{{asset('images/bg.jpg')}}');
        background-repeat:no-repeat;
        background-size:100% 100%;
        height:100vh;
    }
</style>
<body>
    <div class="container">
        <h3 class="p-4 "><center>Student Record Management System</center></h3>
        <div class="row">
            <div class="col-md-6 offset-3">
                <div class="card">
                    <div class="card-header bg-info text-white"><h4>Sign in</h4></div>
                    <div class="card-body" style="border:3px solid #0dcaf0;">
                            <form action="{{ route('admin.login') }}" method="post" autocomplete="off">
                            @csrf
                            <div class="mb-3 mt-3">
                              <label for="login_id" class="form-label">Login Id:</label>
                              <input type="text" class="form-control" id="login_id" value="{{ old('login_id') }}" placeholder="Enter Login Id" name="login_id">
                              <span class="text-danger">{{ $errors->first('login_id') }}</span>
                            </div>
                            <div class="mb-3">
                              <label for="password" class="form-label">Password:</label>
                              <input type="password" class="form-control" id="password" value="{{ old('password') }}" placeholder="Enter password" name="password">
                              <span class="text-danger">{{ $errors->first('password') }}</span>
                            </div>
                            <button type="submit" class="btn btn-primary">Login</button>
                          </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@if(session('error'))
<script>
    alert("{{ session('error') }}");
</script>
@endif
</body>
@endsection
