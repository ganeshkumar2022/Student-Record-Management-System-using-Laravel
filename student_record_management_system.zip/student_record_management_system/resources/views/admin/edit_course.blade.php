@extends('../layouts.master')
@section('title','Admin Panel | Student Record Management System')
@section('content')
<style>
    .myulasdd li a
    {
        padding:13px;
        font-size:18px;
    }
</style>
<body>
    <div class="bg-light text-dark p-3"><h5 class="fw-normal">Student Record Management System</h5></div>
    <div style="width:100%;">
        @include('admin.aheader')
        <div style="width:80%;float:left;">
            <div class="container-fluid">
            <h4 class="pt-4 pb-3">WELCOME ADMIN</h4>
            <div class="card">
                <div class="card-header">Edit Course</div>
                <div class="card-body">
                   <form method="post" autocomplete="off" action="{{ route('update_course',$data->id) }}">
                    @csrf
                    @method('PUT')
                    <div class="row">
                        <div class="col-md-3">
                          <label>Course short name :</label>
                        </div>
                        <div class="col-md-6">
                          <input type="text" class="form-control" placeholder="Enter Course short name" value="{{ $data->course_name }}" name="course_name">
                          <span class="text-danger">{{ $errors->first('course_name') }}</span>
                        </div>
                      </div>
                      <div class="row mt-3">
                        <div class="col-md-3">
                          <label>Course full name :</label>
                        </div>
                        <div class="col-md-6">
                          <input type="text" class="form-control" placeholder="Enter Course full name" value="{{ $data->full_name }}" name="full_name">
                          <span class="text-danger">{{ $errors->first('full_name') }}</span>
                        </div>
                      </div>
                      <div class="row mt-3">
                        <div class="col-md-3">
                          <label>Creation Date :</label>
                        </div>
                        <div class="col-md-6">
                          <input type="text" readonly class="form-control" value="{{ date('Y-m-d') }}" placeholder="Choose creation date" name="creation_date">
                        </div>
                      </div>
                      <div class="mt-3">
                        <input type="submit" name="update" value="Update Course" class="btn btn-primary">
                      </div>
                   </form>
                </div>
            </div>
        </div>
        </div>
    </div>
    @if (session('message'))
      <script>
        alert("{{ session('message') }}");
      </script>
    @endif
</body>
@endsection
