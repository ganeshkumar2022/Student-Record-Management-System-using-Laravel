@extends('../layouts.master')
@section('title','Admin Panel | Student Record Management System')
@section('content')
<style>
    .myulasdd li a
    {
        padding:13px;
        font-size:18px;
    }
</style>
<body>
    <div class="bg-light text-dark p-3"><h5 class="fw-normal">Student Record Management System</h5></div>
    <div style="width:100%;">
        @include('admin.aheader')
        <div style="width:80%;float:left;">
            <div class="container-fluid">
            <h4 class="pt-4 pb-3">WELCOME ADMIN</h4>
            <div class="card">
                <div class="card-header">Add Subject</div>
                <div class="card-body">
                   <form method="post" autocomplete="off" action="{{ route('create_subject') }}">
                    @csrf
                    <div class="row">
                        <div class="col-md-3">
                          <label>Course short name :</label>
                        </div>
                        <div class="col-md-6">
                          <select class="form-select" name="course_id">
                            <option value="">Choose Course</option>
                            @foreach ($courses as $course)
                            <option value="{{ $course->id }}" {{ old('course_id')==$course->id ? "selected" : "" }} >{{ $course->course_name."(".$course->full_name.")" }}</option>
                            @endforeach
                          </select>
                          <span class="text-danger">{{ $errors->first('course_id') }}</span>
                        </div>
                      </div>
                      <div class="row mt-3">
                        <div class="col-md-3">
                          <label>Subject 1 :</label>
                        </div>
                        <div class="col-md-6">
                          <input type="text" class="form-control" placeholder="Enter Subject 1" value="{{ old('subject1') }}" name="subject1">
                          <span class="text-danger">{{ $errors->first('subject1') }}</span>
                        </div>
                      </div>
                      <div class="row mt-3">
                        <div class="col-md-3">
                          <label>Subject 2 :</label>
                        </div>
                        <div class="col-md-6">
                          <input type="text" class="form-control" placeholder="Enter Subject 2" value="{{ old('subject2') }}" name="subject2">
                          <span class="text-danger">{{ $errors->first('subject2') }}</span>
                        </div>
                      </div>
                      <div class="row mt-3">
                        <div class="col-md-3">
                          <label>Subject 3 :</label>
                        </div>
                        <div class="col-md-6">
                          <input type="text" class="form-control" placeholder="Enter Subject 3" value="{{ old('subject3') }}" name="subject3">
                          <span class="text-danger">{{ $errors->first('subject3') }}</span>
                        </div>
                      </div>
                      <div class="row mt-3">
                        <div class="col-md-3">
                          <label>Subject 4 :</label>
                        </div>
                        <div class="col-md-6">
                          <input type="text" class="form-control" placeholder="Enter Subject 4" value="{{ old('subject4') }}" name="subject4">
                          <span class="text-danger">{{ $errors->first('subject4') }}</span>
                        </div>
                      </div>
                      <div class="mt-3">
                        <input type="submit" name="create" value="Create Subject" class="btn btn-primary">
                      </div>
                   </form>
                </div>
            </div>
        </div>
        </div>
    </div>
    @if (session('message'))
      <script>
        alert("{{ session('message') }}");
      </script>
    @endif
</body>
@endsection
