@extends('../layouts.master')
@section('title','Admin Panel | Student Record Management System')
@section('content')
<style>
    .myulasdd li a
    {
        padding:13px;
        font-size:18px;
    }
</style>
<body>
    <div class="bg-light text-dark p-3"><h5 class="fw-normal">Student Record Management System</h5></div>
    <div style="width:100%;">
        @include('admin.aheader')
        <div style="width:80%;float:left;">
            <div class="container-fluid">
            <h4 class="pt-4 pb-3">WELCOME ADMIN</h4>
            <div class="card">
                <div class="card-header">Manage Courses</div>
                <div class="card-body">
                    <table class="table table-bordered">
                        <tr class="table-primary">
                            <th>S.No</th>
                            <th>Course Name</th>
                            <th>Full Name</th>
                            <th>Created Date</th>
                            <th>Action</th>
                        </tr>
                        @foreach ($data as $key=>$row)
                        <tr>
                            <td>{{ $key+1 }}</td>
                            <td>{{ $row->course_name }}</td>
                            <td>{{ $row->full_name }}</td>
                            <td>{{ $row->creation_date }}</td>
                            <td>
                                <a href="{{ route('edit_course',$row->id) }}" class="btn btn-success">Edit</a>
                                <a href="{{ route('delete_course',$row->id) }}" class="btn btn-danger">Delete</a>
                            </td>
                        </tr>
                        @endforeach
                    </table>
                </div>
            </div>
        </div>
        </div>
    </div>
    @if (session('message'))
      <script>
        alert("{{ session('message') }}");
      </script>
    @endif
</body>
@endsection
