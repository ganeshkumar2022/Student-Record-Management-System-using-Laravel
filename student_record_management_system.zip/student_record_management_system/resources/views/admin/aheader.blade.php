<div style="width:20%;float:left;height:100vh;" class=" bg-info">
    <ul class="nav flex-column myulasdd">
        <li class="nav-item">
          <a class="nav-link text-white" href="{{ url('admin_dashboard') }}"><i class="fa-solid fa-gauge"></i> Dashboard</a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-white choose_course" href="javascript:void(0)"><i class="fa-solid fa-file"></i> Course <i class="fa-solid fa-angle-right float-end"></i></a>
        </li>
        <div class="courses" style="display:none;">
            <li class="nav-item">
                <a class="nav-link text-white" href="{{ url('add_courses') }}">&nbsp;&nbsp;&nbsp; Add Course</a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="{{ url('view_course') }}">&nbsp;&nbsp;&nbsp; View Course</a>
            </li>
        </div>
        <li class="nav-item">
          <a class="nav-link text-white choose_subject" href="javascript:void(0)"><i class="fa-solid fa-file-signature"></i> Subject <i class="fa-solid fa-angle-right float-end"></i></a>
        </li>
        <div class="subjects"  style="display:none;">
            <li class="nav-item">
                <a class="nav-link text-white" href="{{ url('add_subject') }}">&nbsp;&nbsp;&nbsp; Add Subject</a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-white" href="{{ url('view_subject') }}">&nbsp;&nbsp;&nbsp; View Subject</a>
            </li>
        </div>
        <li class="nav-item">
          <a class="nav-link text-white" href="{{ url('register') }}"><i class="fa-solid fa-user"></i> Register</a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-white" href="{{ url('view_students') }}"><i class="fa-solid fa-users"></i> View Students</a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-white" href="{{ url('add_session') }}"><i class="fa-regular fa-calendar-days"></i> Session</a>
          </li>

        <li class="nav-item">
            <a class="nav-link text-white" href="{{ url('update_password') }}"><i class="fa-solid fa-key"></i> Change Password</a>
        </li>
        <li class="nav-item">
            <a class="nav-link text-white" href="{{ url('admin_logout') }}"><i class="fa-solid fa-arrow-right-from-bracket"></i> Logout</a>
        </li>
      </ul>
</div>
<script>
    $(document).ready(function(){
        $(".choose_course").click(function(){
            $(".courses").toggle();
        });
        $(".choose_subject").click(function(){
            $(".subjects").toggle();
        });
    });
</script>
