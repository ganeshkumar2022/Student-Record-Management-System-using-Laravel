@extends('../layouts.master')
@section('title','Admin Panel | Student Record Management System')
@section('content')
<style>
    .myulasdd li a
    {
        padding:13px;
        font-size:18px;
    }
</style>
<body>
    <div class="bg-light text-dark p-3"><h5 class="fw-normal">Student Record Management System</h5></div>
    <div style="width:100%;">
        @include('admin.aheader')
        <div style="width:80%;float:left;">
            <div class="container-fluid">
            <h4 class="pt-4 pb-3">WELCOME ADMIN</h4>
            <div class="card">
                <div class="card-header">Change password</div>
                <div class="card-body">
                   <form method="post" autocomplete="off" action="{{ route('change_password') }}">
                    @method('PUT')
                    @csrf
                    <div class="row">
                        <div class="col-md-3">
                          <label>Current password :</label>
                        </div>
                        <div class="col-md-6">
                          <input type="password" class="form-control" placeholder="Enter Current password" value="{{ old('current_password') }}" name="current_password">
                          <span class="text-danger">{{ $errors->first('current_password') }}</span>
                        </div>
                      </div>
                      <div class="row mt-3">
                        <div class="col-md-3">
                          <label>New Password :</label>
                        </div>
                        <div class="col-md-6">
                          <input type="password" class="form-control" placeholder="Enter New Password" value="{{ old('password') }}" name="password">
                          <span class="text-danger">{{ $errors->first('password') }}</span>
                        </div>
                      </div>
                      <div class="row mt-3">
                        <div class="col-md-3">
                          <label>Re type new password :</label>
                        </div>
                        <div class="col-md-6">
                          <input type="password" class="form-control"  placeholder="Enter Confirm password" value="{{ old('password_confirmation') }}" name="password_confirmation">
                          <span class="text-danger">{{ $errors->first('password_confirmation') }}</span>
                        </div>
                      </div>
                      <div class="mt-3">
                        <input type="submit" name="create" value="Update Password" class="btn btn-primary">
                      </div>
                   </form>
                </div>
            </div>
        </div>
        </div>
    </div>
    @if (session('message'))
      <script>
        alert("{{ session('message') }}");
      </script>
    @endif
</body>
@endsection
