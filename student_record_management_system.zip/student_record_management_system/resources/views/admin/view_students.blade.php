@extends('../layouts.master')
@section('title','Admin Panel | Student Record Management System')
@section('content')
<style>
    .myulasdd li a
    {
        padding:13px;
        font-size:18px;
    }
</style>
<body>
    <div class="bg-light text-dark p-3"><h5 class="fw-normal">Student Record Management System</h5></div>
    <div style="width:100%;">
        @include('admin.aheader')
        <div style="width:80%;float:left;">
            <div class="container-fluid">
            <h4 class="pt-4 pb-3">WELCOME ADMIN</h4>
            <div class="card">
                <div class="card-header">Manage Students</div>
                <div class="card-body">
                    <table class="table table-bordered">
                        <tr class="table-primary">
                            <th>S.No</th>
                            <th>Register No</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Mobile no</th>
                            <th>Course</th>
                            <th>Subject</th>
                            <th>Action</th>
                        </tr>
                        @foreach ($data as $key=>$row)
                        <tr>
                            <td>{{ $key+1 }}</td>
                            <td>{{ $row->student_id }}</td>
                            <td>{{ $row->first_name." ".$row->middle_name." ".$row->last_name }}</td>
                            <td>{{ $row->email }}</td>
                            <td>{{ $row->mobile }}</td>
                            <td>{{ $row->course_name }}</td>
                            <td>{{ $row->subject1."+".$row->subject2."+".$row->subject3."+".$row->subject4 }}</td>
                            <td>
                                <a href="{{ route('edit_student',$row->student_id) }}" class="btn btn-success">Edit</a>
                                <a href="{{ route('delete_student',$row->student_id) }}" class="btn btn-danger">Delete</a>
                            </td>
                        </tr>
                        @endforeach
                    </table>
                </div>
            </div>
        </div>
        </div>
    </div>
    @if (session('message'))
      <script>
        alert("{{ session('message') }}");
      </script>
    @endif
</body>
@endsection
