<?php

namespace App\Http\Controllers;

use App\Models\Admin;
use App\Models\Courses;
use App\Models\Mysession;
use App\Models\Student;
use App\Models\Subject;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AdminController extends Controller
{
    public function index()
    {
        return view('home');
    }
    public function admin_login(Request $request)
    {
        $request->validate([
            'login_id'=>'required',
            'password'=>'required'
        ]);

        $login_id=$request->input('login_id');
        $password=$request->input('password');

        $admin=Admin::where("employee_id",$login_id)->first();
        if($admin)
        {
            if(password_verify($password,$admin->password))
            {
                $request->session()->put('aid',$admin->id);
                return redirect()->route('admin.dashboard');
            }
            else
            {
                return redirect()->route('home')->with('error','Login id or password incorrect');
            }

        }
        else
        {
            return redirect()->route('home')->with('error','Login id or password incorrect');
        }
    }
    public function get_state($id)
    {
        $subjects=Subject::where("course_id",$id)->first();
        return $subjects->subject1."+".$subjects->subject2."+".$subjects->subject3."+".$subjects->subject4;
    }
    public function admin_dashboard()
    {
        if(session()->has('aid'))
        {
            $subjects=Subject::count();
            $courses=Courses::count();
            $students=Student::count();
            return view("admin.dashboard",compact('subjects','courses','students'));
        }
        else
        {
            return redirect()->route('home');
        }
    }
    public function add_session()
    {
        if(session()->has('aid'))
        {
            $id=1;
            $data=Mysession::find($id);
            return view("admin.add_session",compact('data'));
        }
        else
        {
            return redirect()->route('home');
        }
    }
    public function update_session(Request $request,$id)
    {
        if(session()->has('aid'))
        {
           $request->validate([
            'my_session'=>'required'
           ]);


           try
           {
           $data=Mysession::find($id);
           $data->mysession_name=$request->input('my_session');
           $data->save();


           return redirect()->route('add_session')->with('message',"Session updated successfully");
           }
           catch(Exception $e)
           {
             return redirect()->route('add_session')->with('message',$e->getMessage());
           }

        }
        else
        {
            return redirect()->route('home');
        }
    }
    public function register_student(Request $request)
    {
        if(session()->has('aid'))
        {
            $request->validate([
                'course_id'=>'required',
                'current_session'=>'required',
                'first_name'=>'required',
                'last_name'=>'required',
                'guardian_name'=>'required',
                'family_income'=>'required',
                'physically_challenged'=>'required',

                'gender'=>'required',
                'occupation'=>'required',
                'caste'=>'required',
                'nationality'=>'required',
                'mobile'=>'required',
                'country'=>'required',
                'city'=>'required',
                'correspondance_address'=>'required',
                'email'=>'required',
                'state'=>'required',
                'permenant_address'=>'required',
                'tenth_rollno'=>'required',
                'tenth_year_of_passing'=>'required',
                'twelth_rollno'=>'required',
                'twelth_year_of_passing'=>'required'
            ]);


            try
            {
            $student=new Student();
            $student->course_id=$request->input('course_id');
            $student->current_session=$request->input('current_session');
            $student->first_name=$request->input('first_name');
            $student->last_name=$request->input('last_name');
            $student->guardian_name=$request->input('guardian_name');
            $student->family_income=$request->input('family_income');
            $student->physically_challenged=$request->input('physically_challenged');
            $student->middle_name=$request->input('middle_name')?$request->input('middle_name'):" ";
            $student->gender=$request->input('gender');
            $student->occupation=$request->input('occupation');
            $student->caste=$request->input('caste');
            $student->nationality=$request->input('nationality');
            $student->mobile=$request->input('mobile');
            $student->country=$request->input('country');
            $student->city=$request->input('city');
            $student->correspondance_address=$request->input('correspondance_address');
            $student->email=$request->input('email');
            $student->state=$request->input('state');
            $student->permenant_address=$request->input('permenant_address');
            $student->tenth_rollno=$request->input('tenth_rollno');
            $student->tenth_year_of_passing=$request->input('tenth_year_of_passing');
            $student->twelth_rollno=$request->input('twelth_rollno');
            $student->twelth_year_of_passing=$request->input('twelth_year_of_passing');
            $student->save();

            return redirect()->route('view_students')->with('message','Student Added successfully');
            }
            catch(Exception $e)
            {
                return redirect()->route('register')->with('message',$e->getMessage());
            }


        }
        else
        {
            return redirect()->route('home');
        }
    }
    public function update_student(Request $request,$id)
    {
        if(session()->has('aid'))
        {
            $request->validate([
                'course_id'=>'required',
                'current_session'=>'required',
                'first_name'=>'required',
                'last_name'=>'required',
                'guardian_name'=>'required',
                'family_income'=>'required',
                'physically_challenged'=>'required',

                'gender'=>'required',
                'occupation'=>'required',
                'caste'=>'required',
                'nationality'=>'required',
                'mobile'=>'required',
                'country'=>'required',
                'city'=>'required',
                'correspondance_address'=>'required',
                'email'=>'required',
                'state'=>'required',
                'permenant_address'=>'required',
                'tenth_rollno'=>'required',
                'tenth_year_of_passing'=>'required',
                'twelth_rollno'=>'required',
                'twelth_year_of_passing'=>'required'
            ]);


            try
            {
            $student=Student::find($id);
            $student->course_id=$request->input('course_id');
            $student->current_session=$request->input('current_session');
            $student->first_name=$request->input('first_name');
            $student->last_name=$request->input('last_name');
            $student->guardian_name=$request->input('guardian_name');
            $student->family_income=$request->input('family_income');
            $student->physically_challenged=$request->input('physically_challenged');
            $student->middle_name=$request->input('middle_name')?$request->input('middle_name'):" ";
            $student->gender=$request->input('gender');
            $student->occupation=$request->input('occupation');
            $student->caste=$request->input('caste');
            $student->nationality=$request->input('nationality');
            $student->mobile=$request->input('mobile');
            $student->country=$request->input('country');
            $student->city=$request->input('city');
            $student->correspondance_address=$request->input('correspondance_address');
            $student->email=$request->input('email');
            $student->state=$request->input('state');
            $student->permenant_address=$request->input('permenant_address');
            $student->tenth_rollno=$request->input('tenth_rollno');
            $student->tenth_year_of_passing=$request->input('tenth_year_of_passing');
            $student->twelth_rollno=$request->input('twelth_rollno');
            $student->twelth_year_of_passing=$request->input('twelth_year_of_passing');
            $student->save();

            return redirect()->route('edit_student',$id)->with('message','Student Updated successfully');
            }
            catch(Exception $e)
            {
                return redirect()->route('edit_student',$id)->with('message',$e->getMessage());
            }


        }
        else
        {
            return redirect()->route('home');
        }
    }
    public function register()
    {
        if(session()->has('aid'))
        {
            $courses=Courses::all();
            $Mysession=Mysession::find(1);
            return view("admin.register",compact('courses','Mysession'));
        }
        else
        {
            return redirect()->route('home');
        }
    }
    public function update_password()
    {
        if(session()->has('aid'))
        {
            return view('admin.update_password');
        }
        else
        {
            return redirect()->route('home');
        }
    }
    public function change_password(Request $request)
    {
        if(session()->has('aid'))
        {
            $request->validate([
                'current_password'=>'required',
                'password'=>'required|confirmed',
                'password_confirmation'=>'required'
            ]);

            $aid=session()->get('aid');
            $admin=Admin::find($aid);
            $current_password=$request->input('current_password');
            $password=password_hash($request->input('password'),PASSWORD_DEFAULT);

            if(password_verify($current_password,$admin->password))
            {
               try
               {
               $admin->password=$password;
               $admin->save();
               return redirect()->route('update_password')->with('message','Password updated successfully');
               }
               catch(Exception $e)
               {
                return redirect()->route('update_password')->with('message',$e->getMessage());
               }
            }
            else
            {
                return redirect()->route('update_password')->with('message','Old password not match');
            }
        }
        else
        {
            return redirect()->route('home');
        }
    }
    public function edit_student($id)
    {
        if(session()->has('aid'))
        {
            $student=Student::find($id);
            $courses=Courses::all();
            return view("admin.edit_student",compact('student','courses'));
        }
        else
        {
            return redirect()->route('home');
        }
    }
    public function admin_logout()
    {
        if(session()->has('aid'))
        {
            session()->forget('aid');
            return redirect()->route('home');
        }
    }
    public function add_courses()
    {
        if(session()->has('aid'))
        {
            return view("admin.add_course");
        }
        else
        {
            return redirect()->route('home');
        }
    }
    public function create_course(Request $request)
    {
        $request->validate([
            'course_name' => 'required',
            'full_name' => 'required'
        ]);

        try
        {
        $course_name=$request->input('course_name');
        $full_name=$request->input('full_name');
        $creation_date=$request->input('creation_date');

        $data=new Courses();
        $data->course_name=$course_name;
        $data->full_name=$full_name;
        $data->creation_date=$creation_date;
        $data->save();
        return redirect()->route('add_course')->with('message','Courses created successfully');
        }
        catch(Exception $e)
        {
            return redirect()->route('add_course')->with('message','Error :'.$e->getMessage());
        }
    }
    public function add_subjects()
    {
        if(session()->has('aid'))
        {
            $courses=Courses::all();
            return view("admin.add_subject",compact('courses'));
        }
        else
        {
            return redirect()->route('home');
        }
    }
    public function create_subject(Request $request)
    {
        $request->validate([
            'course_id' => 'required',
            'subject1' => 'required',
            'subject2' => 'required',
            'subject3' => 'required',
            'subject4' => 'required'
        ]);

        try
        {
        $course_id=$request->input('course_id');
        $subject1=$request->input('subject1');
        $subject2=$request->input('subject2');
        $subject3=$request->input('subject3');
        $subject4=$request->input('subject4');

        $data=new Subject();
        $data->course_id=$course_id;
        $data->subject1=$subject1;
        $data->subject2=$subject2;
        $data->subject3=$subject3;
        $data->subject4=$subject4;
        $data->save();
        return redirect()->route('add_subject')->with('message','Subjects created successfully');
        }
        catch(Exception $e)
        {
           return redirect()->route('add_subject')->with('message','Error :'.$e->getMessage());
        }
    }
    public function update_subject(Request $request,$id)
    {
        $request->validate([
            'course_id' => 'required',
            'subject1' => 'required',
            'subject2' => 'required',
            'subject3' => 'required',
            'subject4' => 'required'
        ]);

        try
        {
        $course_id=$request->input('course_id');
        $subject1=$request->input('subject1');
        $subject2=$request->input('subject2');
        $subject3=$request->input('subject3');
        $subject4=$request->input('subject4');

        $data=Subject::find($id);
        $data->course_id=$course_id;
        $data->subject1=$subject1;
        $data->subject2=$subject2;
        $data->subject3=$subject3;
        $data->subject4=$subject4;

        $data->save();
        return redirect()->route('edit_subject',$id)->with('message','Subjects updated successfully');
        }
        catch(Exception $e)
        {
           return redirect()->route('edit_subject',$id)->with('message','Error :'.$e->getMessage());
        }
    }
    public function edit_course(Request $request,$id)
    {
        if(session()->has('aid'))
        {
            $data=Courses::find($id);
            return view('admin.edit_course',compact('data'));
        }
        else
        {
            return redirect()->route('home');
        }
    }
    public function edit_subject(Request $request,$id)
    {
        if(session()->has('aid'))
        {
            $courses=Courses::all();
            $data=Subject::where('subject_id',$id)->first();
            return view('admin.edit_subject',compact('data','courses'));
        }
        else
        {
            return redirect()->route('home');
        }
    }
    public function update_course(Request $request,$id)
    {
        $request->validate([
            'course_name' => 'required',
            'full_name' => 'required'
        ]);

        try
        {
        $course_name=$request->input('course_name');
        $full_name=$request->input('full_name');
        $creation_date=$request->input('creation_date');

        $data=Courses::find($id);
        $data->course_name=$course_name;
        $data->full_name=$full_name;
        $data->creation_date=$creation_date;
        $data->save();
        return redirect()->route('edit_course',$id)->with('message','Courses Updated successfully');
        }
        catch(Exception $e)
        {
            return redirect()->route('edit_course',$id)->with('message','Error :'.$e->getMessage());
        }
    }
    public function view_course()
    {
        if(session()->has('aid'))
        {
            $data=Courses::all();
            return view('admin.view_courses',compact('data'));
        }
        else
        {
            return redirect()->route('home');
        }

    }
    public function view_students()
    {
        if(session()->has('aid'))
        {
            $data=DB::select("select * from students inner join courses on students.course_id=courses.id inner join subjects on subjects.course_id=courses.id");
            return view('admin.view_students',compact('data'));
        }
        else
        {
            return redirect()->route('home');
        }

    }
    public function view_subjects()
    {
        if(session()->has('aid'))
        {
            $data=DB::table("subjects")->leftJoin('courses',"subjects.course_id","=","courses.id")->select("subjects.*","courses.course_name","courses.full_name")->get();
            return view('admin.view_subjects',compact('data'));
        }
        else
        {
            return redirect()->route('home');
        }

    }
    public function delete_course($id)
    {
        if(session()->has('aid'))
        {
            $data=Courses::find($id);
            $data->delete();
            return redirect()->route('view_course');
        }
        else
        {
            return redirect()->route('home');
        }
    }
    public function delete_subject($id)
    {
        if(session()->has('aid'))
        {
            $data=Subject::where("subject_id",$id);
            $data->delete();
            return redirect()->route('view_subjects');
        }
        else
        {
            return redirect()->route('home');
        }
    }
    public function delete_student($id)
    {
        if(session()->has('aid'))
        {
            $data=Student::find($id);
            $data->delete();
            return redirect()->route('view_students');
        }
        else
        {
            return redirect()->route('home');
        }
    }
}
